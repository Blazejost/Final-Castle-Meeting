#include "stdafx.h"
#include "Tile.h"

Tile::Tile() {
	hasItem = false;
	wall = false;
}

Tile::~Tile()
{

}

